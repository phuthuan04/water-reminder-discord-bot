"""
bot.py
File chính - khởi tạo bot Discord, xử lý reminder theo lịch,
nút bấm "Đã uống / Chưa uống", và slash command xem thống kê.

Chạy: python bot.py
"""

import os
import io
import random
import logging
from datetime import datetime

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import matplotlib
matplotlib.use("Agg")  # không cần giao diện đồ họa, chỉ xuất ảnh
import matplotlib.pyplot as plt

import database as db
import messages as msg

# ---------- Cấu hình & logging ----------
load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("water-bot")

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
CHANNEL_ID = int(os.getenv("CHANNEL_ID", "0"))
TARGET_USER_ID = os.getenv("TARGET_USER_ID", "0")
TIMEZONE = os.getenv("TIMEZONE", "Asia/Ho_Chi_Minh")
REMINDER_TIMES = [t.strip() for t in os.getenv("REMINDER_TIMES", "08:00,12:00,15:00,20:00").split(",")]

if not DISCORD_TOKEN:
    raise RuntimeError("Chưa cấu hình DISCORD_TOKEN trong file .env")

# ---------- Khởi tạo bot ----------
intents = discord.Intents.default()
intents.message_content = False  # không cần đọc nội dung tin nhắn, chỉ dùng slash command + button

bot = commands.Bot(command_prefix="!", intents=intents)
scheduler = AsyncIOScheduler(timezone=TIMEZONE)


# ---------- Giao diện nút bấm (View) ----------
class WaterReminderView(discord.ui.View):
    """
    View chứa 2 nút: Đã uống / Chưa uống.
    timeout=None để nút không bao giờ hết hạn (Discord giới hạn 15 phút nếu không set None).
    """

    def __init__(self, target_user_id: str):
        super().__init__(timeout=None)
        self.target_user_id = target_user_id

    async def _check_owner(self, interaction: discord.Interaction) -> bool:
        """Chỉ cho đúng người được nhắc mới được bấm nút."""
        if str(interaction.user.id) != str(self.target_user_id):
            await interaction.response.send_message(
                "Nút này không dành cho bạn nha 😅", ephemeral=True
            )
            return False
        return True

    @discord.ui.button(label="✅ Đã uống", style=discord.ButtonStyle.success, custom_id="water_done")
    async def done_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._check_owner(interaction):
            return

        db.log_water(interaction.user.id)
        today_count = db.get_today_count(interaction.user.id)

        # Vô hiệu hóa nút sau khi bấm để tránh log trùng
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)

        await interaction.followup.send(
            f"{msg.get_random_praise()}\n"
            f"📊 Hôm nay đã uống nước **{today_count} lần** rồi đó!",
        )

    @discord.ui.button(label="⏳ Chưa uống", style=discord.ButtonStyle.secondary, custom_id="water_not_yet")
    async def not_yet_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._check_owner(interaction):
            return

        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)

        await interaction.followup.send(msg.get_random_nudge())


# ---------- Logic gửi nhắc nhở ----------
async def send_water_reminder():
    """Được scheduler gọi theo giờ đã cấu hình."""
    channel = bot.get_channel(CHANNEL_ID)
    if channel is None:
        log.error("Không tìm thấy channel ID %s - kiểm tra lại .env", CHANNEL_ID)
        return

    text = f"<@{TARGET_USER_ID}> {msg.get_random_reminder()}"

    # 30% khả năng kèm thêm câu hỏi thăm sức khỏe cho đỡ nhàm
    if random.random() < 0.3:
        text += f"\n\n{msg.get_random_health_checkin()}"

    view = WaterReminderView(target_user_id=TARGET_USER_ID)
    await channel.send(text, view=view)
    log.info("Đã gửi nhắc nhở lúc %s", datetime.now().strftime("%H:%M:%S"))


def setup_scheduler():
    """Đăng ký các job nhắc nhở theo REMINDER_TIMES trong .env"""
    for time_str in REMINDER_TIMES:
        try:
            hour, minute = map(int, time_str.split(":"))
        except ValueError:
            log.warning("Bỏ qua giờ nhắc không hợp lệ: %s", time_str)
            continue

        scheduler.add_job(
            send_water_reminder,
            trigger=CronTrigger(hour=hour, minute=minute),
            id=f"reminder_{time_str}",
            replace_existing=True,
        )
        log.info("Đã đăng ký nhắc nhở lúc %s hằng ngày", time_str)


# ---------- Sự kiện bot ----------
@bot.event
async def on_ready():
    db.init_db()

    # Đăng ký lại view "vĩnh viễn" để nút vẫn hoạt động sau khi bot restart
    bot.add_view(WaterReminderView(target_user_id=TARGET_USER_ID))

    if not scheduler.running:
        setup_scheduler()
        scheduler.start()

    try:
        synced = await bot.tree.sync()
        log.info("Đã đồng bộ %d slash command(s)", len(synced))
    except Exception as e:
        log.error("Lỗi khi đồng bộ slash command: %s", e)

    log.info("Bot đã sẵn sàng: %s", bot.user)


# ---------- Slash Commands ----------
@bot.tree.command(name="uong", description="Ghi nhận thủ công 1 lần đã uống nước")
async def uong(interaction: discord.Interaction):
    db.log_water(interaction.user.id)
    today_count = db.get_today_count(interaction.user.id)
    await interaction.response.send_message(
        f"{msg.get_random_praise()}\n📊 Hôm nay đã uống nước **{today_count} lần**."
    )


@bot.tree.command(name="homnay", description="Xem số lần đã uống nước hôm nay")
async def homnay(interaction: discord.Interaction):
    today_count = db.get_today_count(interaction.user.id)
    await interaction.response.send_message(f"📊 Hôm nay bạn đã uống nước **{today_count} lần** rồi!")


@bot.tree.command(name="thongke", description="Xem biểu đồ uống nước 7 ngày gần nhất")
async def thongke(interaction: discord.Interaction):
    await interaction.response.defer()  # vẽ biểu đồ có thể mất >3s, cần defer trước

    stats = db.get_last_n_days_stats(interaction.user.id, n_days=7)
    days = list(stats.keys())
    counts = list(stats.values())

    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(days, counts, color="#4FC3F7")
    ax.set_title("Số lần uống nước - 7 ngày gần nhất", fontsize=14, fontweight="bold")
    ax.set_ylabel("Số lần")
    ax.set_ylim(bottom=0)

    # Ghi số lên đầu mỗi cột cho dễ đọc
    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.1,
            str(count),
            ha="center",
            fontsize=10,
        )

    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format="png", dpi=120)
    buffer.seek(0)
    plt.close(fig)

    file = discord.File(buffer, filename="thongke.png")
    total = sum(counts)
    avg = total / len(counts) if counts else 0

    await interaction.followup.send(
        content=f"📈 Trung bình **{avg:.1f} lần/ngày** trong 7 ngày qua.",
        file=file,
    )


# ---------- Chạy bot ----------
if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)

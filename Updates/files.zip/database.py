"""
database.py
Định nghĩa schema và các hàm thao tác dữ liệu (CRUD) cho bot.
Dùng SQLite + SQLAlchemy ORM - nhẹ, không cần cài server riêng.
"""

from datetime import datetime, date, timedelta
from sqlalchemy import create_engine, Column, Integer, String, DateTime, func
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()
engine = create_engine("sqlite:///water_reminder.db", echo=False)
SessionLocal = sessionmaker(bind=engine)


class WaterLog(Base):
    """Mỗi lần người dùng bấm nút 'Đã uống' sẽ tạo 1 dòng ở đây."""
    __tablename__ = "water_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, nullable=False)       # Discord user ID
    timestamp = Column(DateTime, default=datetime.utcnow)


class MoodCheckin(Base):
    """Lưu lại các lần hỏi thăm sức khỏe (mở rộng cho giai đoạn sau)."""
    __tablename__ = "mood_checkins"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    note = Column(String, nullable=True)


def init_db():
    """Tạo bảng nếu chưa tồn tại. Gọi 1 lần khi bot khởi động."""
    Base.metadata.create_all(engine)


def log_water(user_id: str):
    """Ghi nhận 1 lần uống nước."""
    session = SessionLocal()
    try:
        entry = WaterLog(user_id=str(user_id), timestamp=datetime.utcnow())
        session.add(entry)
        session.commit()
    finally:
        session.close()


def get_today_count(user_id: str) -> int:
    """Đếm số lần đã uống nước trong ngày hôm nay (theo giờ UTC)."""
    session = SessionLocal()
    try:
        today_start = datetime.combine(date.today(), datetime.min.time())
        count = (
            session.query(func.count(WaterLog.id))
            .filter(WaterLog.user_id == str(user_id))
            .filter(WaterLog.timestamp >= today_start)
            .scalar()
        )
        return count or 0
    finally:
        session.close()


def get_last_n_days_stats(user_id: str, n_days: int = 7) -> dict:
    """
    Trả về dict {ngày: số lần uống nước} cho n ngày gần nhất, dùng để vẽ biểu đồ.
    """
    session = SessionLocal()
    try:
        start_date = date.today() - timedelta(days=n_days - 1)
        start_datetime = datetime.combine(start_date, datetime.min.time())

        logs = (
            session.query(WaterLog)
            .filter(WaterLog.user_id == str(user_id))
            .filter(WaterLog.timestamp >= start_datetime)
            .all()
        )

        # Khởi tạo đủ n ngày với giá trị 0, để biểu đồ không bị thiếu ngày
        stats = {
            (start_date + timedelta(days=i)).strftime("%d/%m"): 0
            for i in range(n_days)
        }

        for log in logs:
            key = log.timestamp.strftime("%d/%m")
            if key in stats:
                stats[key] += 1

        return stats
    finally:
        session.close()


def log_mood_checkin(user_id: str, note: str = None):
    session = SessionLocal()
    try:
        entry = MoodCheckin(user_id=str(user_id), timestamp=datetime.utcnow(), note=note)
        session.add(entry)
        session.commit()
    finally:
        session.close()

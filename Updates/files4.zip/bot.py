"""
bot.py
File chính - khởi tạo bot Discord, xử lý reminder theo lịch,
nút bấm "Đã uống / Chưa uống", và slash command xem thống kê.

Mô hình multi-user: mỗi người tự gõ /dangky để nhận nhắc nhở,
phù hợp khi có nhiều người cùng dùng chung 1 bot (VD: bạn + người yêu).

Chạy: python bot.py
"""

import os
import io
import csv
import time
import random
import logging
from datetime import datetime, timedelta

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import matplotlib
matplotlib.use("Agg")  # không cần giao diện đồ họa, chỉ xuất ảnh
import matplotlib.pyplot as plt

import database as db
import messages as msg

# ---------- Cấu hình & logging ----------
load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

# Ép logging dùng giờ Việt Nam (UTC+7) thay vì giờ hệ thống server,
# vì time.localtime() mặc định phụ thuộc múi giờ OS của server (Railway).
logging.Formatter.converter = lambda *args: time.gmtime(time.time() + 7 * 3600)
log = logging.getLogger("water-bot")

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
CHANNEL_ID = int(os.getenv("CHANNEL_ID", "0"))
TIMEZONE = os.getenv("TIMEZONE", "Asia/Ho_Chi_Minh")
REMINDER_TIMES = [t.strip() for t in os.getenv("REMINDER_TIMES", "08:00,12:00,15:00,20:00").split(",")]
FOLLOWUP_MINUTES = int(os.getenv("REMINDER_FOLLOWUP_MINUTES", "30"))

if not DISCORD_TOKEN:
    raise RuntimeError("Chưa cấu hình DISCORD_TOKEN trong file .env")

# ---------- Khởi tạo bot ----------
intents = discord.Intents.default()
intents.message_content = False  # không cần đọc nội dung tin nhắn, chỉ dùng slash command + button

bot = commands.Bot(command_prefix="!", intents=intents)
scheduler = AsyncIOScheduler(timezone=TIMEZONE)


def vn_now() -> datetime:
    """
    Giờ hiện tại theo giờ Việt Nam, tính từ datetime.utcnow() + 7 giờ.
    Không dùng datetime.now() vì nó phụ thuộc múi giờ hệ điều hành của server
    (Railway có thể chạy ở UTC hoặc múi giờ khác), trong khi datetime.utcnow()
    luôn cho giờ UTC chuẩn bất kể server đặt ở đâu.
    """
    return datetime.utcnow() + timedelta(hours=7)


# ---------- Giao diện nút bấm (View) ----------
class WaterReminderView(discord.ui.View):
    """
    View chứa 2 nút: Đã uống / Chưa uống.
    timeout=None để nút không bao giờ hết hạn (Discord giới hạn 15 phút nếu không set None).

    Lưu ý: 1 tin nhắn nhắc nhở có thể gửi cho NHIỀU người đăng ký cùng lúc
    (VD: cả bạn và người yêu cùng dùng chung kênh). Ai bấm nút thì log cho
    chính người đó, không giới hạn chỉ 1 người cố định.
    """

    def __init__(self):
        super().__init__(timeout=None)

    async def _check_registered(self, interaction: discord.Interaction) -> bool:
        """Chỉ người đã /dangky mới được log qua nút bấm."""
        if not db.is_user_registered(interaction.user.id):
            await interaction.response.send_message(
                "Bạn chưa đăng ký nhận nhắc nhở nha, gõ lệnh `/dangky` trước đã 😉",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="✅ Đã uống", style=discord.ButtonStyle.success, custom_id="water_done")
    async def done_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._check_registered(interaction):
            return

        db.log_water(interaction.user.id)
        today_count = db.get_today_count(interaction.user.id)
        streak_count = db.get_streak(interaction.user.id)

        # Trả lời riêng (ephemeral) cho người bấm, không disable nút chung
        # vì tin nhắn này có thể còn người khác chưa bấm.
        await interaction.response.send_message(
            f"{msg.get_random_praise()}\n"
            f"📊 Hôm nay bạn đã uống nước **{today_count} lần** rồi đó!\n"
            f"🔥 Streak: **{streak_count} ngày**",
            ephemeral=True,
        )

    @discord.ui.button(label="⏳ Chưa uống", style=discord.ButtonStyle.secondary, custom_id="water_not_yet")
    async def not_yet_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._check_registered(interaction):
            return

        await interaction.response.send_message(msg.get_random_nudge(), ephemeral=True)


# ---------- Logic gửi nhắc nhở ----------
async def send_water_reminder():
    """Được scheduler gọi theo giờ đã cấu hình."""
    channel = bot.get_channel(CHANNEL_ID)
    if channel is None:
        log.error("Không tìm thấy channel ID %s - kiểm tra lại .env", CHANNEL_ID)
        return

    active_users = db.get_active_users()
    if not active_users:
        log.info("Chưa có ai đăng ký (/dangky) - bỏ qua lượt nhắc này")
        return

    mentions = " ".join(f"<@{user_id}>" for user_id, _ in active_users)
    text = f"{mentions} {msg.get_random_reminder()}"

    # 30% khả năng kèm thêm câu hỏi thăm sức khỏe cho đỡ nhàm
    if random.random() < 0.3:
        text += f"\n\n{msg.get_random_health_checkin()}"

    view = WaterReminderView()
    await channel.send(text, view=view)
    log.info("Đã gửi nhắc nhở lúc %s cho %d người", vn_now().strftime("%H:%M:%S"), len(active_users))

    # Ghi lại số lần uống nước hiện tại của từng người (baseline),
    # để lát nữa so sánh xem có ai chưa uống thêm lần nào không.
    baseline = {user_id: db.get_today_count(user_id) for user_id, _ in active_users}
    user_ids = [user_id for user_id, _ in active_users]

    scheduler.add_job(
        check_and_followup,
        trigger="date",
        run_date=vn_now() + timedelta(minutes=FOLLOWUP_MINUTES),
        args=[user_ids, baseline],
        misfire_grace_time=300,
    )


async def check_and_followup(user_ids: list, baseline: dict):
    """
    Chạy sau FOLLOWUP_MINUTES kể từ lúc gửi reminder.
    Ai chưa uống thêm lần nào so với baseline sẽ được nhắc lại riêng.
    """
    channel = bot.get_channel(CHANNEL_ID)
    if channel is None:
        return

    still_not_done = [
        uid for uid in user_ids
        if db.get_today_count(uid) <= baseline.get(uid, 0)
    ]

    if not still_not_done:
        return

    mentions = " ".join(f"<@{uid}>" for uid in still_not_done)
    await channel.send(f"{mentions} {msg.get_random_followup()}")
    log.info("Đã nhắc lại cho %d người chưa uống nước", len(still_not_done))


def setup_scheduler():
    """Đăng ký các job nhắc nhở theo REMINDER_TIMES trong .env"""
    for time_str in REMINDER_TIMES:
        try:
            hour, minute = map(int, time_str.split(":"))
        except ValueError:
            log.warning("Bỏ qua giờ nhắc không hợp lệ: %s", time_str)
            continue

        scheduler.add_job(
            send_water_reminder,
            trigger=CronTrigger(hour=hour, minute=minute),
            id=f"reminder_{time_str}",
            replace_existing=True,
        )
        log.info("Đã đăng ký nhắc nhở lúc %s hằng ngày", time_str)


# ---------- Sự kiện bot ----------
@bot.event
async def on_ready():
    db.init_db()

    # Đăng ký lại view "vĩnh viễn" để nút vẫn hoạt động sau khi bot restart
    bot.add_view(WaterReminderView())

    if not scheduler.running:
        setup_scheduler()
        scheduler.start()

    try:
        synced = await bot.tree.sync()
        log.info("Đã đồng bộ %d slash command(s)", len(synced))
    except Exception as e:
        log.error("Lỗi khi đồng bộ slash command: %s", e)

    log.info("Bot đã sẵn sàng: %s", bot.user)


# ---------- Slash Commands ----------
@bot.tree.command(name="dangky", description="Đăng ký nhận nhắc nhở uống nước từ bot")
async def dangky(interaction: discord.Interaction):
    is_new = db.register_user(interaction.user.id, interaction.user.display_name)
    if is_new:
        await interaction.response.send_message(
            "🎉 Đăng ký thành công! Từ giờ bạn sẽ được nhắc uống nước theo lịch nha.\n"
            "Muốn ngừng nhận thì gõ `/huy`."
        )
    else:
        await interaction.response.send_message("Bạn đã đăng ký từ trước rồi nha 😉")


@bot.tree.command(name="huy", description="Ngừng nhận nhắc nhở uống nước")
async def huy(interaction: discord.Interaction):
    db.unregister_user(interaction.user.id)
    await interaction.response.send_message(
        "Đã ngừng nhắc nhở. Lịch sử uống nước của bạn vẫn được lưu, "
        "muốn nhận lại thì gõ `/dangky` bất cứ lúc nào nha."
    )


@bot.tree.command(name="uong", description="Ghi nhận thủ công 1 lần đã uống nước")
async def uong(interaction: discord.Interaction):
    db.log_water(interaction.user.id)
    today_count = db.get_today_count(interaction.user.id)
    await interaction.response.send_message(
        f"{msg.get_random_praise()}\n📊 Hôm nay đã uống nước **{today_count} lần**."
    )


@bot.tree.command(name="homnay", description="Xem số lần đã uống nước hôm nay")
async def homnay(interaction: discord.Interaction):
    today_count = db.get_today_count(interaction.user.id)
    streak = db.get_streak(interaction.user.id)
    await interaction.response.send_message(
        f"📊 Hôm nay bạn đã uống nước **{today_count} lần** rồi!\n"
        f"🔥 Streak hiện tại: **{streak} ngày** liên tục"
    )


@bot.tree.command(name="streak", description="Xem chuỗi ngày uống nước liên tục của bạn")
async def streak(interaction: discord.Interaction):
    streak_count = db.get_streak(interaction.user.id)
    if streak_count == 0:
        await interaction.response.send_message(
            "Chưa có streak nào cả, uống nước ngay hôm nay để bắt đầu chuỗi mới nha! 💧"
        )
    else:
        await interaction.response.send_message(
            f"🔥 Bạn đang giữ streak **{streak_count} ngày** liên tục uống nước! Cố lên nha!"
        )


@bot.tree.command(name="test", description="[Test] Gửi thử tin nhắn nhắc nhở ngay lập tức, không cần đợi tới giờ")
async def test_reminder(interaction: discord.Interaction):
    await interaction.response.send_message("Đang gửi thử tin nhắn nhắc nhở... ⏳", ephemeral=True)
    await send_water_reminder()


@bot.tree.command(name="xuatdata", description="Xuất toàn bộ dữ liệu thô ra file CSV")
async def xuatdata(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)

    # --- File 1: water_logs.csv ---
    logs = db.get_all_water_logs()
    logs_buffer = io.StringIO()
    writer = csv.writer(logs_buffer)
    writer.writerow(["user_id", "display_name", "timestamp_vn"])
    for user_id, display_name, timestamp in logs:
        vn_timestamp = timestamp + timedelta(hours=7)
        writer.writerow([user_id, display_name or "", vn_timestamp.isoformat()])
    logs_bytes = io.BytesIO(logs_buffer.getvalue().encode("utf-8-sig"))  # utf-8-sig để Excel đọc đúng tiếng Việt

    # --- File 2: users.csv ---
    users = db.get_all_users_raw()
    users_buffer = io.StringIO()
    writer = csv.writer(users_buffer)
    writer.writerow(["user_id", "display_name", "is_active"])
    for user_id, display_name, is_active in users:
        writer.writerow([user_id, display_name or "", is_active])
    users_bytes = io.BytesIO(users_buffer.getvalue().encode("utf-8-sig"))

    await interaction.followup.send(
        content=f"📦 Đã xuất dữ liệu: **{len(logs)} lượt uống nước**, **{len(users)} người dùng**.",
        files=[
            discord.File(logs_bytes, filename="water_logs.csv"),
            discord.File(users_bytes, filename="users.csv"),
        ],
        ephemeral=True,
    )


@bot.tree.command(name="thongke", description="Xem biểu đồ uống nước 7 ngày gần nhất")
async def thongke(interaction: discord.Interaction):
    await interaction.response.defer()  # vẽ biểu đồ có thể mất >3s, cần defer trước

    stats = db.get_last_n_days_stats(interaction.user.id, n_days=7)
    days = list(stats.keys())
    counts = list(stats.values())

    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(days, counts, color="#4FC3F7")
    ax.set_title("Số lần uống nước - 7 ngày gần nhất", fontsize=14, fontweight="bold")
    ax.set_ylabel("Số lần")
    ax.set_ylim(bottom=0)

    # Ghi số lên đầu mỗi cột cho dễ đọc
    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.1,
            str(count),
            ha="center",
            fontsize=10,
        )

    plt.tight_layout()

    buffer = io.BytesIO()
    plt.savefig(buffer, format="png", dpi=120)
    buffer.seek(0)
    plt.close(fig)

    file = discord.File(buffer, filename="thongke.png")
    total = sum(counts)
    avg = total / len(counts) if counts else 0

    await interaction.followup.send(
        content=f"📈 Trung bình **{avg:.1f} lần/ngày** trong 7 ngày qua.",
        file=file,
    )


@bot.tree.command(name="huongdan", description="Đăng hướng dẫn sử dụng bot vào kênh này")
async def huongdan(interaction: discord.Interaction):
    guide = (
        "## 💧 Hướng dẫn dùng Stay Hydrated Bot\n\n"
        "**Bước 1 - Đăng ký (bắt buộc trước tiên):**\n"
        "`/dangky` — đăng ký nhận nhắc nhở uống nước theo lịch cố định trong ngày.\n\n"
        "**Các lệnh chính:**\n"
        "• `/uong` — ghi nhận thủ công 1 lần đã uống nước (không cần đợi bot nhắc)\n"
        "• `/homnay` — xem số lần đã uống nước hôm nay + streak hiện tại\n"
        "• `/streak` — xem chuỗi ngày uống nước liên tục\n"
        "• `/thongke` — xem biểu đồ 7 ngày gần nhất\n"
        "• `/xuatdata` — xuất toàn bộ lịch sử ra file CSV (mở bằng Excel)\n"
        "• `/huy` — ngừng nhận nhắc nhở (lịch sử vẫn được giữ, đăng ký lại bất cứ lúc nào)\n\n"
        "**Khi bot nhắc nhở:** sẽ có 2 nút **✅ Đã uống** / **⏳ Chưa uống** ngay dưới tin nhắn, bấm trực tiếp là được, không cần gõ lệnh.\n\n"
        "**Nếu quên bấm nút:** bot sẽ tự nhắc lại sau 1 khoảng thời gian nếu thấy bạn vẫn chưa uống thêm lần nào 💧"
    )
    await interaction.response.send_message(guide)


@bot.tree.command(name="thongbao", description="[Admin] Đăng thông báo cập nhật mới của bot vào kênh này")
@app_commands.describe(noi_dung="Nội dung cập nhật muốn thông báo")
async def thongbao(interaction: discord.Interaction, noi_dung: str):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(
            "Lệnh này chỉ dành cho admin server thôi nha 😅", ephemeral=True
        )
        return

    active_users = db.get_active_users()
    mentions = " ".join(f"<@{uid}>" for uid, _ in active_users) if active_users else ""

    text = f"## 📢 Cập nhật mới\n\n{noi_dung}"
    if mentions:
        text += f"\n\n{mentions}"

    await interaction.response.send_message(text)


# ---------- Chạy bot ----------
if __name__ == "__main__":
    bot.run(DISCORD_TOKEN)
